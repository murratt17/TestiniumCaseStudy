package Hooks;

import TestPages.MainPage;
import TestPages.MybasketPage;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.*;


import java.io.FileWriter;   // Import the FileWriter class


public class HelperFunctions {


    public static void scrollDownForSecondPage(WebDriver web, WebElement element)
    {
        JavascriptExecutor js = (JavascriptExecutor) web;

        js.executeScript("arguments[0].scrollIntoView();", element);
        js.executeScript("window.scrollBy(0,-150)", "");
    }

    public static void scrollDownForRandomElement(WebDriver web, WebElement element) throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) web;

        js.executeScript("arguments[0].scrollIntoView();", element);
        Thread.sleep(100);
    }
    public static void writeToFile(String p1 , String p2) {
        try {
            FileWriter myWriter = new FileWriter("titleandprice.txt");
            myWriter.write(p1);
            myWriter.write("\n");
            myWriter.write(p2);
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }



    public boolean compareThePrices(MybasketPage basketPage)
    {
        String line = "";
        String price = "";

        try {

            BufferedReader bufferreader = new BufferedReader(new FileReader("titleandprice.txt"));

            int i = 0;
            while ((line = bufferreader.readLine()) != null) {

                if(i == 1)
                    price = line;
                i++;
            }

        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }


        if (basketPage.getTotalPrice().getText().compareTo(price)==0)
            return  true;
        else
            return false;



    }
}
