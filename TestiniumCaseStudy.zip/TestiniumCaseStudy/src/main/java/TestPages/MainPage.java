package TestPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MainPage {

    WebDriver driver;
    @FindBy(xpath = "//input[contains(@aria-label,'Keşfetmeye Bak')]")
    WebElement SearchBox;
    @FindBy(id = "add-to-basket")
    WebElement sepeteEkle;
    @FindBy(xpath = "//span[contains(text(),'Sepetim')]")
    WebElement sepetim;

    @FindBy(xpath = "//button[contains(@data-cy,'search-find-button')]")
    WebElement BtnSearch;

    @FindBy(xpath = " //span[contains(text(),'Sonraki')]")
    WebElement Sonraki;

    @FindBy(xpath = "//a[contains(@aria-label,'2. sayfa')]")
    WebElement IkinciSayfa;

    @FindBy(xpath = "//*[@id=\"sp-title\"]")
    WebElement TitleOfPC;

    @FindBy(xpath = "//*[@id=\"sp-price-highPrice\"]")
    WebElement PriceOfPC;

    @FindBy(xpath = "//a[contains(text(),'Sepete Git')]")
    WebElement SepeteGit;
    public MainPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public WebElement getBtnSepeteEkle() {
        return sepeteEkle;
    }

    public WebElement getSepeteGit(){
        return SepeteGit;
    }

    public WebElement getSepetim() {
        return sepetim;
    }

    public WebElement getBtnSearch() {
        return BtnSearch;
    }

    public WebElement getSearchBox() {
        return SearchBox;
    }

    public WebElement getPriceOfPC(){
        return PriceOfPC;
    }

    public WebElement getSonraki() {
        return Sonraki;
    }

    public WebElement getIkinciSayfa(){
        return IkinciSayfa;
    }
    public WebElement getTitleOfPC() {
        return TitleOfPC;
    }
    public WebElement getRandomComputer(WebDriver driver, int randomNumber)
    {

        WebElement randomElement;

        System.out.println(Integer.toString(randomNumber));

        String xpathRandom = "//*[@id=\"2\"]/li["+ Integer.toString(randomNumber) + "]";
        randomElement = driver.findElement(By.xpath(xpathRandom));
        return randomElement;

    }
    public boolean checkIfSecondPage(WebDriver driver) {

        if(driver.getCurrentUrl().contains("sf=2")) return  true;
        else return  false;
    }
}
