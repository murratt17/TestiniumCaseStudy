package TestPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MybasketPage {

    WebDriver driver;
    @FindBy(xpath = "//*[@class='total-price']/strong")
    WebElement TotalPrice;

    @FindBy(xpath = "//*[@class='gg-input gg-input-select ']")
    WebElement Amount;

    @FindBy(xpath = "//*[@class='amount']/option[2]")
    WebElement AmountTwo;

    @FindBy(xpath = "//*[@class='gg-d-16 gg-m-14 detail-text']")
    WebElement NumberOfPC;

    @FindBy(xpath = "(//*[@class='btn-delete btn-update-item'])[1]")
    WebElement DeletePC;

    @FindBy(xpath = "//*[@class='gg-d-19 gg-w-21 gg-t-19 gg-m-18']")
    WebElement EmptyMessage;

    public MybasketPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);

    }

    public WebElement getAmount() {
        return Amount;
    }

    public WebElement getEmptyMessage() {
        return EmptyMessage;
    }

    public WebElement getDeletePC() {
        return DeletePC;
    }

    public WebElement getNumberOfPC() {
        return NumberOfPC;
    }

    public WebElement getAmountTwo() {
        return AmountTwo;
    }

    public WebElement getTotalPrice() {
        return TotalPrice;
    }
}
