import Hooks.HelperFunctions;
import TestPages.MainPage;
import TestPages.MybasketPage;
import dev.failsafe.internal.util.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.Random;

import static java.util.concurrent.TimeUnit.SECONDS;

public class TestGittiGidiyor {

    WebDriver driver;
    Actions action;
    Random randomGenerator;
    int randomNumber;

    HelperFunctions helperFunctions;

    MybasketPage sepetim;

    private Logger logger;

    @Before
    public void setUp() throws Exception {
        logger = LoggerFactory.getLogger(TestGittiGidiyor.class);

        System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.gittigidiyor.com/");




        driver.manage().timeouts().implicitlyWait(10, SECONDS);

        driver.manage().timeouts().pageLoadTimeout(200, SECONDS);

    }

    @Test
    public void test() throws InterruptedException {

        action = new Actions(driver);

         randomGenerator = new Random();
         randomNumber = randomGenerator.nextInt(20) + 1;
         helperFunctions = new HelperFunctions();
         sepetim = new MybasketPage(driver);


        MainPage mainPage = new MainPage(driver);
        mainPage.getSearchBox().sendKeys("Bilgisayar");
        logger.info("Bilgisayar searched in searchbox");
        mainPage.getBtnSearch().click();

        helperFunctions.scrollDownForSecondPage(driver , mainPage.getIkinciSayfa() );

        mainPage.getIkinciSayfa().click();
        driver.manage().timeouts().pageLoadTimeout(200, SECONDS);

        Assert.isTrue(mainPage.checkIfSecondPage(driver), "Driver is not in second page");



        helperFunctions.scrollDownForRandomElement(driver , mainPage.getRandomComputer(driver,randomNumber) );

        mainPage.getRandomComputer(driver,randomNumber).click();

        HelperFunctions.writeToFile( mainPage.getTitleOfPC().getText() , mainPage.getPriceOfPC().getText());

        helperFunctions.scrollDownForRandomElement(driver , mainPage.getBtnSepeteEkle() );

        clickOn(driver ,  mainPage.getBtnSepeteEkle() , 20);

        action.moveToElement(mainPage.getSepetim()).perform();
        Thread.sleep(1000);

        clickOn(driver , mainPage.getSepeteGit() , 20);



        Assert.isTrue(helperFunctions.compareThePrices(sepetim) , "The prices in the basket and text are different");

        clickOn(driver , sepetim.getAmount() , 20);
        clickOn(driver ,  sepetim.getAmountTwo() , 20);


        Thread.sleep(1000);
        Assert.isTrue(sepetim.getNumberOfPC().getText().contains("2 Adet") , "The number of PC is wrong");

        clickOn(driver , sepetim.getDeletePC() , 20);

        Thread.sleep(1000);

        Assert.isTrue(sepetim.getEmptyMessage().getText().contains("Sepetinizde ürün bulunmamaktadır"), "error empty basket message");

    }

    @After
    public void tearDown()
    {
        driver.close();

    }

    public void clickOn(WebDriver driver1, WebElement element, int timeout) throws InterruptedException {
        new WebDriverWait(driver1, Duration.ofSeconds(timeout)).until(ExpectedConditions.elementToBeClickable(element));// Expectedcondition for the

        element.click();

    }
}
